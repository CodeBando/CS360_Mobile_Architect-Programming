package com.BandykM.eventtrackr;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.work.WorkManager;

import com.BandykM.eventtrackr.database.EventDao;
import com.BandykM.eventtrackr.database.EventEntity;
import com.BandykM.eventtrackr.database.EventRepository;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CombinedAdapter combinedAdapter;
    private EventRepository eventRepository;
    private List<EventEntity> eventList;
    private List<CombinedItem> combinedList;
    private EventDao eventDao;
    private long loggedInUserId;
    private Toolbar toolbar;
    private boolean isSelectionMode = false;
    private List<Long> selectedItems = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        Log.d("onCreate", "onCreate has been executed");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_recycle_view);

        loggedInUserId = getIntent().getLongExtra("loggedInUserId", -1);

        toolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Event Schedule");
        getSupportActionBar().setDisplayHomeAsUpEnabled(isSelectionMode);


        recyclerView = findViewById(R.id.combinedRecyclerView);
        eventList = new ArrayList<>();
        combinedList = new ArrayList<>();

        eventRepository = EventRepository.getInstance(this);
        eventDao = eventRepository.getEventDao();

        // Initialize the adapter and set it to the RecyclerView
        combinedAdapter = new com.BandykM.eventtrackr.CombinedAdapter(combinedList, new com.BandykM.eventtrackr.CombinedAdapter.ItemClickListener() {
            @Override
            public void onItemClick(int position) {
                if (!isSelectionMode) {
                    Intent intent = new Intent(MainActivity.this, DisplayEvent.class);
                    intent.putExtra("eventId", combinedList.get(position).getId());
                    intent.putExtra("loggedInUserId", loggedInUserId);
                    startActivity(intent);
                }
                else {
                    CombinedItem item = combinedList.get(position);
                    item.setSelected(!item.isSelected());

                    long eventId = combinedList.get(position).getId();
                    if (item.isSelected()) {
                        selectedItems.add(eventId);
                    } else {
                        selectedItems.remove(eventId);
                    }

                    // Update the background color of the clicked item
                    combinedAdapter.notifyItemChanged(position);
                }
            }

            @Override
            public void onItemLongClick(int position) {
                isSelectionMode = true;
                getSupportActionBar().setDisplayHomeAsUpEnabled(isSelectionMode);
                toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Exit selection mode when the Up button is clicked
                        exitSelectionMode();
                    }
                });

                long eventId = combinedList.get(position).getId();
                selectedItems.clear();
                selectedItems.add(eventId);

                // Show the delete_event action item
                invalidateOptionsMenu();

                // Update the background color of selected item
                combinedAdapter.notifyItemChanged(position);
            }
        });

        recyclerView.setAdapter(combinedAdapter);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onAddEventClick(view);
            }
        });

        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);

// Check if the flag exists and is set to true
        boolean isChannelCreated = sharedPreferences.getBoolean("notification_channel_created", false);

        if (!isChannelCreated) {
            // Create the notification channel
            createNotificationChannel();

            // Set the flag to true
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("notification_channel_created", true);
            editor.apply();
        }

        // Fetch and display events from the database
        loadAndDisplayEvents();
    }

    private void loadAndDisplayEvents() {
        Log.d("loadAndDisplayEvents", "Method to load events was reached");
        eventList.clear();
        combinedList.clear();

        List<EventEntity> eventList = eventDao.getSortedEvents(loggedInUserId);
        Log.d("loadAndDisplayEvents", "User events loaded: " + eventList.size());
        String currentDate = null;

        for (EventEntity event : eventList) {
            if (currentDate == null || !currentDate.equals(event.getDate())) {
                // Add a DateFragment
                combinedList.add(new CombinedItem(event.getDate()));
                currentDate = event.getDate();
            }

            // Add an EventFragment
            combinedList.add(new CombinedItem(event.getEventname(), event.getTime(), event.getId()));
        }

        // Notify the adapter that the data set has changed
        combinedAdapter.notifyDataSetChanged();
    }

    // Handle selection mode exit
    private void exitSelectionMode() {
        isSelectionMode = false;
        toolbar.setNavigationOnClickListener(null);

        for (int i = 0; i < combinedList.size(); i++) {
            CombinedItem combinedItem = combinedList.get(i);
            long eventId = combinedItem.getId();

            if (selectedItems.contains(eventId)) {
                combinedItem.setSelected(false);
                // Notify the adapter and reset its background color
                combinedAdapter.notifyItemChanged(i);
            }
        }

        selectedItems.clear();
        getSupportActionBar().setDisplayHomeAsUpEnabled(isSelectionMode);

        // Hide the delete_event action item
        invalidateOptionsMenu();
    }

    // Handle "Add Event" FAB click
    public void onAddEventClick(View view) {
        Intent intent = new Intent(MainActivity.this, AddEvent.class);
        intent.putExtra("loggedInUserId", loggedInUserId);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.app_bar_menu, menu);

        // Show/hide delete_event action item based on selection mode
        MenuItem deleteItem = menu.findItem(R.id.delete_event);
        deleteItem.setVisible(isSelectionMode);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.logout) {
            showLogoutDialog();
            return true;
        }

        else if (itemId == R.id.delete_event) {
            showDeleteConfirmationDialog();
            return true;
        }

        else {
            return super.onOptionsItemSelected(item);
        }
    }

    private void showLogoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Logout")
                .setMessage("Are you sure you want to log out?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Handle logout: Navigate back to the login screen
                        Intent intent = new Intent(MainActivity.this, Login.class);
                        startActivity(intent);
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void showDeleteConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Events")
                .setMessage("Are you sure you want to delete the selected events?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Delete the selected events
                        deleteSelectedEvents();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void deleteSelectedEvents() {
        Log.d("EventDeletion", "Number of selected items: " + selectedItems.size());

        // Delete the selected events from the database
        eventDao.deleteEvents(selectedItems);

        // Clear the selected items
        selectedItems.clear();

        // Update the RecyclerView to reflect the changes
        loadAndDisplayEvents();
        exitSelectionMode();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "EventTrackr";
            String description = "Event Notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("event_notification_channel", name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}