package com.BandykM.eventtrackr.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface EventDao {
    @Insert
    void insertEvent(EventEntity event);

    @Update
    void updateEvent(EventEntity event);

    @Query("SELECT * FROM EventEntity WHERE id = :eventId")
    EventEntity getEventById(long eventId);

    @Query("SELECT * FROM EventEntity WHERE user_id = :userId AND date = :date LIMIT :limit OFFSET :offset")
    List<EventEntity> getEventsForDate(long userId, String date, int limit, int offset);

    @Query("DELETE FROM EventEntity WHERE id IN (:eventIds)")
    void deleteEvents(List<Long> eventIds);

    @Query("SELECT * FROM EventEntity WHERE user_id = :userId ORDER BY date ASC, time ASC")
    List<EventEntity> getSortedEvents(long userId);
}