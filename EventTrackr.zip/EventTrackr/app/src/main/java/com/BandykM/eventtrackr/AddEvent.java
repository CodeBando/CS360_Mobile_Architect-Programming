package com.BandykM.eventtrackr;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import com.BandykM.eventtrackr.database.EventDao;
import com.BandykM.eventtrackr.database.EventEntity;
import com.BandykM.eventtrackr.database.EventRepository;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class AddEvent extends AppCompatActivity {

    private EditText titleEditText, locationEditText, multilineEditText;
    private Button displayDate, displayTime;
    private Calendar calendar;
    private DateFragment dateFragment;
    private TimeFragment timeFragment;
    private EventDao eventDao;
    private long loggedInUserId;
    private String eventDate;
    private String eventTime;
    private long eventID;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_event);

        loggedInUserId = getIntent().getLongExtra("loggedInUserId", -1);

        Toolbar toolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("New Event");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        EventRepository eventDB = EventRepository.getInstance(this);
        eventDao = eventDB.getEventDao();

        titleEditText = findViewById(R.id.titleEditText);
        locationEditText = findViewById(R.id.locationEditText);
        multilineEditText = findViewById(R.id.multilineEditText);
        displayDate = findViewById(R.id.displayDate);
        displayTime = findViewById(R.id.displayTime);

        calendar = Calendar.getInstance();

        dateFragment = new DateFragment();
        timeFragment = new TimeFragment();

        Button pickDateButton = findViewById(R.id.displayDate);
        Button pickTimeButton = findViewById(R.id.displayTime);

        pickDateButton.setOnClickListener(v -> showDatePicker());
        pickTimeButton.setOnClickListener(v -> showTimePicker());


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onSaveEventClick(view);
            }
        });
    }

    private void showDatePicker() {
        dateFragment.show(getSupportFragmentManager(), "datePicker");
    }

    private void showTimePicker() {
        timeFragment.show(getSupportFragmentManager(), "timePicker");
    }
    public void setDate(int year, int month, int dayOfMonth) {
        // Format the selected date
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        calendar.set(year, month, dayOfMonth);

        eventDate = dateFormat.format(calendar.getTime());

        // Update the displayDate button text
        displayDate.setText(eventDate);
    }

    public void setTime(int hourOfDay, int minute) {
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
        calendar.set(Calendar.MINUTE, minute);

        eventTime = timeFormat.format(calendar.getTime());

        // Update the displayTime button text
        displayTime.setText(eventTime);
    }

    public void onSaveEventClick(View view) {
        // Check if event name, date, and time are filled
        String eventName = titleEditText.getText().toString().trim();
        String eventLocation = locationEditText.getText().toString().trim();
        String eventDetails = multilineEditText.getText().toString().trim();

        if (eventName.isEmpty() || eventDate == null || eventTime == null) {
            Toast.makeText(this, "Please fill in event name, date, and time.", Toast.LENGTH_SHORT).show();
        }
        else {
            // Save the event to the database
            EventEntity event = new EventEntity();
            event.setEventname(eventName);
            event.setDate(eventDate);
            event.setTime(eventTime);
            event.setLocation(eventLocation);
            event.setDetails(eventDetails);
            event.setUser_id(loggedInUserId);

            eventDao.insertEvent(event);
            eventID = event.getId(); // Added statement to capture event's id
            Toast.makeText(this, "Event saved", Toast.LENGTH_SHORT).show();

            // Create event notification
            createNotification();
            navigateToMainActivity();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        showCancelDialog();
        return true;
    }

    private void showCancelDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Cancel Event Creation")
                .setMessage("Are you sure you want to cancel creating this event?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Navigate back to the MainActivity
                        navigateToMainActivity();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void createNotification() {
        try {
            // Parse the selected event date and time strings into a Date object
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm a");
            Date eventDateTime = dateFormat.parse(eventDate + " " + eventTime);

            // Calculate the scheduled send time by subtracting 30 minutes
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(eventDateTime);
            calendar.add(Calendar.MINUTE, -30);
            long scheduledSendTime = calendar.getTimeInMillis();

            // Check if the event is in the future
            if (scheduledSendTime > System.currentTimeMillis()) {
                // Create a Data object to pass event ID and details
                Data inputData = new Data.Builder()
                        .putLong("eventID", eventID)
                        .putString("eventTitle", titleEditText.getText().toString().trim())
                        .putString("eventTime", eventTime) // Pass the event time as a string
                        .build();

                // Create one-time notification request
                OneTimeWorkRequest notificationWorkRequest = new OneTimeWorkRequest.Builder(EventWorker.class)
                        .setInputData(inputData)
                        .setInitialDelay(scheduledSendTime - System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                        .addTag("eventID")
                        .build();

                WorkManager.getInstance(this).enqueueUniqueWork("event_notification_work_" + eventID, ExistingWorkPolicy.REPLACE, notificationWorkRequest);
            } else {
                // Event is in the past or very close to the current time
                // Handle it accordingly
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private void navigateToMainActivity() {
        Intent intent = new Intent(AddEvent.this, MainActivity.class);
        intent.putExtra("loggedInUserId", loggedInUserId);
        startActivity(intent);
        finish();
    }
}