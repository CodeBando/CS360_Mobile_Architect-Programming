package com.BandykM.eventtrackr.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface UserDao {
    @Insert
    void insertUser(UserEntity user);

    // Query a user by username
    @Query("SELECT * FROM users WHERE username = :username")
    LiveData<UserEntity> getUserByUsername(String username);

    // Validate user credentials
    @Query("SELECT * FROM users WHERE username = :username AND password = :password")
    LiveData<UserEntity> validateUserCredentials(String username, String password);

}