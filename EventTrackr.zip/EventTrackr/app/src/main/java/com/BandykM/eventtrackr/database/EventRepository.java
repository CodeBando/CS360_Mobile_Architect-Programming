package com.BandykM.eventtrackr.database;

import android.content.Context;
import androidx.room.Room;

public class EventRepository {
    private static EventRepository eventRepo;
    private final EventDao eventDao;
    private final UserDao userDao;

    public static EventRepository getInstance(Context context) {
        if(eventRepo == null) {
            eventRepo = new EventRepository(context);
        }
        return eventRepo;
    }

    private EventRepository(Context context) {
        EventDatabase eventDB = Room.databaseBuilder(context, EventDatabase.class, "event.db")
                .allowMainThreadQueries()
                .build();

        eventDao = eventDB.eventDao();
        userDao = eventDB.userDao();
    }

    public EventDao getEventDao() { return eventDao; }

    public UserDao getUserDao() { return userDao; }
}
