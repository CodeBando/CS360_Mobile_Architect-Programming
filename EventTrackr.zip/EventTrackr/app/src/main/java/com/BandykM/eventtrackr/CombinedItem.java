package com.BandykM.eventtrackr;

import android.icu.text.SimpleDateFormat;

import java.text.ParseException;
import java.util.Date;

public class CombinedItem {
    private String date; // Represents date
    private String eventTitle; // Represents event title
    private String eventTime; // Represents event time
    private long id; // Event ID
    private boolean isDateItem; // Indicates whether it's a date item or event item
    private boolean isSelected;

    // Constructor for date item
    public CombinedItem(String date) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat outputFormat = new SimpleDateFormat("MMMM dd, yyyy");

        try {
            Date parsedDate = inputFormat.parse(date);
            this.date = outputFormat.format(parsedDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        this.isDateItem = true;
    }

    // Constructor for event item
    public CombinedItem(String eventTitle, String eventTime, Long id) {
        this.eventTitle = eventTitle;
        this.eventTime = eventTime;
        this.isDateItem = false;
        this.isSelected = false;
        this.id = id;
    }

    public boolean isDate() {
        return isDateItem;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        this.isSelected = selected;
    }

    public String getDate() {
        return date;
    }

    public String getEventTitle() {
        return eventTitle;
    }

    public String getEventTime() {
        return eventTime;
    }

    public Long getId() {
        return id;
    }
}