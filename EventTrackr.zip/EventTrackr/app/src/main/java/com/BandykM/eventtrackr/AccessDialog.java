package com.BandykM.eventtrackr;

import android.content.Context;
import android.content.SharedPreferences;

public class AccessDialog {
    private static final String PREFS_NAME = "MyPrefs";
    private static final String SMS_PERMISSION_GRANTED = "sms_permission_granted";
    private static final String NOTIFICATION_PERMISSION_GRANTED = "notification_permission_granted";

    public static boolean isSmsPermissionGranted(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean(SMS_PERMISSION_GRANTED, false);
    }

    public static void setSmsPermissionGranted(Context context, boolean granted) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SMS_PERMISSION_GRANTED, granted);
        editor.apply();
    }

    public static boolean isNotificationPermissionGranted(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean(NOTIFICATION_PERMISSION_GRANTED, false);
    }

    public static void setNotificationPermissionGranted(Context context, boolean granted) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(NOTIFICATION_PERMISSION_GRANTED, granted);
        editor.apply();
    }
}
