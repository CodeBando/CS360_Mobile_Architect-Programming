package com.BandykM.eventtrackr;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.BandykM.eventtrackr.database.EventRepository;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import com.BandykM.eventtrackr.database.EventDao;
import com.BandykM.eventtrackr.database.EventEntity;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DisplayEvent extends AppCompatActivity {

    private EditText titleEditText, locationEditText, multilineEditText;
    private Button displayDate, displayTime;
    private DateDisplayFrag dateFragment;
    private TimeDisplayFrag timeFragment;
    FloatingActionButton fab;
    private String eventDate;
    private String eventTime;
    private Calendar calendar;
    private EventDao eventDao;
    private long eventId, loggedInUserId;
    private boolean isEditing = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display_event);

        Toolbar toolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Event Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Retrieve event ID and logged-in user ID from extras
        eventId = getIntent().getLongExtra("eventId", -1);
        loggedInUserId = getIntent().getLongExtra("loggedInUserId", -1);

        // Initialize UI elements
        titleEditText = findViewById(R.id.titleText);
        locationEditText = findViewById(R.id.locationText);
        multilineEditText = findViewById(R.id.multilineEditText);
        displayDate = findViewById(R.id.displayDate);
        displayTime = findViewById(R.id.displayTime);

        calendar = Calendar.getInstance();

        // Initialize EventDao
        EventRepository eventDB = EventRepository.getInstance(this);
        eventDao = eventDB.getEventDao();

        // Set initial state of UI elements
        setEditable(false);
        setBackgrounds();
        updateEventDisplay();



        dateFragment = new DateDisplayFrag();
        timeFragment = new TimeDisplayFrag();

        displayDate.setOnClickListener(v -> showDatePicker());
        displayTime.setOnClickListener(v -> showTimePicker());

        fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isEditing) {
                    // Save changes and disable editing
                    isEditing = false;
                    saveChanges();
                    setBackgrounds();
                } else {
                    // Enable editing
                    isEditing = true;
                    setEditable(true);
                    fab.setImageResource(R.drawable.save_24);
                    setBackgrounds();
                }
            }
        });
    }

    private void setBackgrounds() {
        if (isEditing) {
            titleEditText.setBackgroundResource(R.drawable.text_outline);
            locationEditText.setBackgroundResource(R.drawable.text_outline);
            multilineEditText.setBackgroundResource(R.drawable.text_outline);
            displayDate.setBackgroundResource(R.drawable.text_outline);
            displayTime.setBackgroundResource(R.drawable.text_outline);
        }
        else {
            titleEditText.setBackgroundResource(R.drawable.text_outline_trans);
            locationEditText.setBackgroundResource(R.drawable.text_outline_trans);
            multilineEditText.setBackgroundResource(R.drawable.text_outline_trans);
            displayDate.setBackgroundResource(R.drawable.text_outline_trans);
            displayTime.setBackgroundResource(R.drawable.text_outline_trans);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        if (isEditing) {
            showCancelDialog();
        }
        else {
            navigateToMainActivity();
        }
        return true;
    }

    private void updateEventDisplay() {
        // Retrieve event data using the event ID
        EventEntity event = eventDao.getEventById(eventId);

        if (event != null) {
            // Populate UI elements with event details
            titleEditText.setText(event.getEventname());
            locationEditText.setText(event.getLocation());
            multilineEditText.setText(event.getDetails());

            // Parse event date and time to set the calendar
            SimpleDateFormat getDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat setDateFormat = new SimpleDateFormat("MMMM dd, yyyy");
            SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
            try {
                calendar.setTime(getDateFormat.parse(event.getDate()));
                eventDate = event.getDate();
                displayDate.setText(setDateFormat.format(calendar.getTime()));
                calendar.setTime(timeFormat.parse(event.getTime()));
                eventTime = event.getTime();
                displayTime.setText(eventTime);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void showDatePicker() {
        dateFragment.show(getSupportFragmentManager(), "datePicker");
    }

    private void showTimePicker() {
        timeFragment.show(getSupportFragmentManager(), "timePicker");
    }
    public void setDate(int year, int month, int dayOfMonth) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        calendar.set(year, month, dayOfMonth);

        eventDate = dateFormat.format(calendar.getTime());

        displayDate.setText(eventDate);
    }

    public void setTime(int hourOfDay, int minute) {
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
        calendar.set(Calendar.MINUTE, minute);

        eventTime = timeFormat.format(calendar.getTime());

        displayTime.setText(eventTime);
    }

    private void setEditable(boolean editable) {
        // Enable or disable EditText views based on the 'editable' parameter
        titleEditText.setEnabled(editable);
        locationEditText.setEnabled(editable);
        multilineEditText.setEnabled(editable);
        displayDate.setEnabled(editable);
        displayTime.setEnabled(editable);
    }

    private void saveChanges() {
        // Check if event name, date, and time are filled
        String eventName = titleEditText.getText().toString().trim();
        String eventLocation = locationEditText.getText().toString().trim();
        String eventDetails = multilineEditText.getText().toString().trim();

        if (eventName.isEmpty() || eventDate.isEmpty() || eventTime.isEmpty()) {
            Toast.makeText(this, "Please fill in event name, date, and time.", Toast.LENGTH_SHORT).show();
        }
        else {
            // Save the event to the database
            EventEntity event = eventDao.getEventById(eventId);
            event.setId(eventId);
            event.setEventname(eventName);
            event.setDate(eventDate);
            event.setTime(eventTime);
            event.setLocation(eventLocation);
            event.setDetails(eventDetails);
            event.setUser_id(loggedInUserId);

            try {
                eventDao.updateEvent(event);
                Toast.makeText(this, "Event Updated", Toast.LENGTH_SHORT).show();
            }
            catch (Exception e) {
                e.printStackTrace();
            }

            setEditable(false);
            fab.setImageResource(R.drawable.edit_24);
        }
    }

    private void showCancelDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Cancel Event Editing")
                .setMessage("Are you sure you want to cancel editing this event?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        isEditing = false;
                        setEditable(false);
                        fab.setImageResource(R.drawable.edit_24);
                        updateEventDisplay();
                        setBackgrounds();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void navigateToMainActivity() {
        Intent intent = new Intent(DisplayEvent.this, MainActivity.class);
        intent.putExtra("loggedInUserId", loggedInUserId);
        startActivity(intent);
        finish();
    }
}