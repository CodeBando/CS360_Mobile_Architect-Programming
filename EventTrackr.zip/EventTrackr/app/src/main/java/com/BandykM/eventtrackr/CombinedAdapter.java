package com.BandykM.eventtrackr;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CombinedAdapter extends RecyclerView.Adapter<CombinedAdapter.ViewHolder> {

    private static final int VIEW_TYPE_DATE = 0;
    private static final int VIEW_TYPE_EVENT = 1;

    private List<CombinedItem> combinedList;
    private ItemClickListener itemClickListener;

    public CombinedAdapter(List<CombinedItem> combinedList, ItemClickListener itemClickListener) {
        this.combinedList = combinedList;
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());

        if (viewType == VIEW_TYPE_DATE) {
            View dateView = inflater.inflate(R.layout.date_frag, parent, false);
            return new DateViewHolder(dateView);
        } else {
            View eventView = inflater.inflate(R.layout.event_frag, parent, false);
            return new EventViewHolder(eventView);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CombinedItem combinedItem = combinedList.get(position);

        if (getItemViewType(position) == VIEW_TYPE_DATE) {
            ((DateViewHolder) holder).bind(combinedItem.getDate());
        } else {
            ((EventViewHolder) holder).bind(combinedItem.getEventTitle(), combinedItem.getEventTime());
            holder.itemView.setBackgroundResource(combinedItem.isSelected() ? R.color.selectedItemColor : R.color.colorAccent);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle item click
                if (itemClickListener != null) {
                    itemClickListener.onItemClick(position);
                }
            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                // Handle item long click
                if (itemClickListener != null) {
                    itemClickListener.onItemLongClick(position);
                    combinedItem.setSelected(!combinedItem.isSelected());
                    notifyItemChanged(position);
                }
                return true;
            }
        });
    }

    @Override
    public int getItemCount() {
        return combinedList.size();
    }

    @Override
    public int getItemViewType(int position) {
        CombinedItem combinedItem = combinedList.get(position);
        return combinedItem.isDate() ? VIEW_TYPE_DATE : VIEW_TYPE_EVENT;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    public class DateViewHolder extends ViewHolder {
        private TextView dateTextView;

        public DateViewHolder(@NonNull View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
        }

        public void bind(String date) {
            dateTextView.setText(date);
        }
    }

    public class EventViewHolder extends ViewHolder {
        private TextView eventTitle;
        private TextView eventTime;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            eventTitle = itemView.findViewById(R.id.eventTitle);
            eventTime = itemView.findViewById(R.id.eventTime);
        }

        public void bind(String title, String time) {
            eventTitle.setText(title);
            eventTime.setText(time);
        }
    }

    // Interface for item click and long click
    public interface ItemClickListener {
        void onItemClick(int position);
        void onItemLongClick(int position);
    }
}
