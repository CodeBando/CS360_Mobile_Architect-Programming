package com.BandykM.eventtrackr;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.content.Context;
import android.util.Log;

public class EventWorker extends Worker {
    public EventWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        if (areNotificationsEnabled()) {
            // Retrieve eventTitle and eventTime from input data
            long eventID = getInputData().getLong("eventID", 0);
            String eventTitle = getInputData().getString("eventTitle");
            String eventTime = getInputData().getString("eventTime");

            // Create a notification with the event title and event time
            createNotification(eventID, eventTitle, eventTime);
            Log.d("Notification", "Notification has been scheduled");

            return Result.success();
        } else {
            Log.d("Notification", "Notification failure");
            return Result.failure();
        }
    }

    private boolean areNotificationsEnabled() {
        Context context = getApplicationContext();
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
        return notificationManager.areNotificationsEnabled();
    }

    @SuppressLint("MissingPermission")
    private void createNotification(Long eventID, String eventTitle, String eventTime) {
        int notificationID = eventID.intValue();

        // Create a notification with the event title and event time
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), "event_notification_channel")
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Event Reminder")
                .setContentText(eventTitle + " is scheduled to start at " + eventTime)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        Notification notification = builder.build();

        // Show the notification
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(getApplicationContext());

        notificationManager.notify(notificationID, notification);
    }
}
