package com.BandykM.eventtrackr;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;

import com.BandykM.eventtrackr.database.EventRepository;
import com.BandykM.eventtrackr.database.UserDao;
import com.BandykM.eventtrackr.database.UserEntity;

public class Login extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;
    private EventRepository eventDatabase;
    private UserDao userDao;
    private long loggedInUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        // Initialize UI components
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Initialize Room database and UserDao
        eventDatabase = EventRepository.getInstance(this);
        userDao = eventDatabase.getUserDao();

        // Set click listeners for buttons
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve username and password from EditText fields
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Validate user credentials (query the database)
                validateUserCredentials(username, password);
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve username and password from EditText fields
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Check if the username is already in use
                checkUsernameAvailability(username, password);
            }
        });
    }

    private void validateUserCredentials(String username, String password) {
        // database query to check if the user exists and the password is correct
        LiveData<UserEntity> userLiveData = userDao.validateUserCredentials(username, password);

        // Observe the LiveData to get the result
        userLiveData.observe(this, new Observer<UserEntity>() {
            @Override
            public void onChanged(UserEntity userEntity) {
                if (userEntity != null) {
                    // User credentials are valid
                    loggedInUserId = userEntity.getId();

                    permissionHandler();
                }

                else {
                    // User credentials are not valid
                    Toast.makeText(Login.this, "Username or Password is incorrect", Toast.LENGTH_SHORT).show();
                }
                userLiveData.removeObserver(this);
            }
        });
    }

    private void checkUsernameAvailability(String username, String password) {
        LiveData<UserEntity> userLiveData = userDao.getUserByUsername(username);

        // check if a user with this username already exists
        userLiveData.observe(this, new Observer<UserEntity>() {
            @Override
            public void onChanged(UserEntity userEntity) {
                if (userEntity != null) {
                    // Username is already in use
                    Toast.makeText(Login.this, "Username is already in use", Toast.LENGTH_SHORT).show();
                } else {
                    // Username is available; create a new user and log them in
                    createUser(username, password);
                    permissionHandler();
                }
                userLiveData.removeObserver(this);
            }
        });
    }

    private void createUser(String username, String password) {
        // Create a new UserEntity with the provided username and password
        UserEntity newUser = new UserEntity();
        newUser.setUsername(username);
        newUser.setPassword(password);

        userDao.insertUser(newUser);

        loggedInUserId = newUser.getId();
    }

    private void requestNotificationPermission() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Notification Permission")
                .setMessage("Do you want to allow notifications for upcoming events?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Handle notification permission granted
                        AccessDialog.setNotificationPermissionGranted(Login.this, true);
                        dialog.dismiss();
                        startMainActivity();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Handle notification permission denied
                        AccessDialog.setNotificationPermissionGranted(Login.this, false);
                        dialog.dismiss();
                        startMainActivity();
                    }
                })
                .setCancelable(false);

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private void permissionHandler() {
        if (!AccessDialog.isNotificationPermissionGranted(Login.this)) {
            requestNotificationPermission();
        }
        else {
            startMainActivity();
        }
    }

    private void startMainActivity() {
        // Start MainActivity and pass loggedInUserId as an extra
        Intent intent = new Intent(Login.this, MainActivity.class);
        intent.putExtra("loggedInUserId", loggedInUserId);
        startActivity(intent);
        // Finish the current activity
        finish();
    }
}